<?php ?>





<?php $__env->startSection('headder'); ?>

<div class="panel panel-primary" ">
  <div class="panel-heading"><h5>Administración de Usuarios</h5></div>
  <div>
    <ol class="breadcrumb" style="background: white;">
  <li><a href="<?php echo e(url('seguridad')); ?>"><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li class="active"><i class="fa fa-th"></i>Usuarios</li>
  
</ol>
   
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

<a href="<?php echo e(route('users.create')); ?>"><button class="btn btn-success">  Nuevo Usuario</button></a> 

<br/>
<br/>
<?php echo $__env->make('datatable.general.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo e($dataTable->table(['class' => 'table warning grocery-crud-table table display cell-border table-hover compact dataTable_width_auto table-striped', 'id' => 'table'])); ?>



<?php echo $dataTable->scripts(); ?>



<?php echo $__env->make('flashy::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div class="modal-dialog modal-notify modal-danger" role="document">
    <div class="modal-content">
      <div class="modal-header">
           <h3 class="modal-title">Eliminar Usuario</h3>
         <form class="w3-container" action="user/delete" method="POST" onKeypress="if(event.keyCode == 13) event.returnValue = false;">
              <?php echo e(csrf_field()); ?>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="glyphicon glyphicon-erase"></i>Estás seguro de eliminar al usuario
        con ID:
          <span id="nombre" style="font-family: sans-serif; color:black"></span>
          
</br>
             (se perderá la cuenta del usuario)

           <input type="hidden" id="idt" name="idt" value="">

     
    
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="submit" class="btn btn-primary">Aceptar</button>
    </div>
        </form>
         </div>
      </div>

    </div>
  </div>



<script type="text/javascript">
    function Mostrarse(btn){
  var pnr=btn.value;
  document.getElementById("idt").value =pnr;
document.getElementById('nombre').innerHTML =pnr;

}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>