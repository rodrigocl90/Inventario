<?php ?>





<?php $__env->startSection('headder'); ?>


     <ol class="breadcrumb">
  <li><a><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li><a href="<?php echo e(route('roles.index')); ?>"><i class="fa fa-user"></i>Roles</a></li>
  <li class="active"><i class="fa fa-th"></i>Información  de roles</li>
</ol>
   

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

<style type="text/css">
  
    .read{ background: white !important;
     }


.blue{

    border-style: 1px; solid;
  font-size: 15px;
}
.green{color: green;}

</style>





  <div class="row">
  <div class="col-sm-2">
       <a align="right" class="btn btn-warning fa fa-external-link" href="<?php echo e(url('admin/roles')); ?>">
                                        Regresar
                                    </a>
  </div>
  <div class="col-sm-7 blue">
<form class="well form-horizontal">
                      <fieldset>
                         <div class="form-group">
                          <div class="well well-lg" align="center" style="background:yellow;">INFORMACIÓN DE ROL</div>
                            <label class="col-md-4 control-label">Nombre del Rol</label>
                            <div class="col-md-8 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input id="Name" name="Name" class="form-control read" value="<?php echo e($role->name); ?>" type="text" readonly></div>
                            </div>
                         </div>
                         <div class="form-group">
                            <label class="col-md-4 control-label">Nombre a Mostrar</label>
                            <div class="col-md-8 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="display_name" name="display_name"  class="form-control read"  value="<?php echo e($role->display_name); ?>" type="text" readonly></div>
                            </div>
                         </div>
                         <div class="form-group">
                            <label class="col-md-4 control-label">Descripción</label>
                            <div class="col-md-8 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><textarea rows="4" cols="50" id="description" name="description"  class="form-control read" value="$role->description" readonly><?php echo e($role->description); ?></textarea></div>
                            </div>
                         </div>
                         
                        <div class="form-group">
                            <label class="col-md-4 control-label">Permisos:</label>
                            <div class="col-md-8 inputGroupContainer">
                               <div class="form-group">
                         
 <?php if(!empty($permissions)): ?>
<ul class="list-group">
  <li class="list-group-item active">Nombre de Permisos</li>
     <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="list-group-item"><i class="fa fa fa-key green"></i><?php echo e($permission->display_name); ?> <b>(<?php echo e(($permission->description)); ?>)</b></li>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>




                               </div>
                            </div>
                         </div>


                      </fieldset>
                   </form>

  </div>
  


  <div class="col-sm-3">
    

  </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>