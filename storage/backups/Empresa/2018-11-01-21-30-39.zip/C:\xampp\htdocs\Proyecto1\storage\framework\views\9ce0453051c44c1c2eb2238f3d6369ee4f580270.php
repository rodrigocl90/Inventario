<?php $__env->startSection('title', 'Servicio en Mantención'); ?>

<?php $__env->startSection('message', 'Ya volveremos.'); ?>

<?php echo $__env->make('errors::layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>