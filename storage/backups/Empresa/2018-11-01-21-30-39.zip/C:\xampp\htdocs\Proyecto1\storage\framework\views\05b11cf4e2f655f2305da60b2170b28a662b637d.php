<?php ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Administración de roles</div>

                    <div class="panel-body">
                        
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('eliminar')): ?>
                            <div class="alert alert-danger">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>


                        <table class="table table-striped table-bordered table-condensed">
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Nombre</th>
                                <th>Descripcion</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr class="list-users">
                                    <td><?php echo e(++$i); ?></td>
                                    <td><?php echo e($role->display_name); ?></td>
                                    <td><?php echo e($role->description); ?></td>
                                    <td>
                                        
                                           <?php if (\Entrust::can('role-list')) : ?>
                                    <a class="btn btn-info" href="<?php echo e(route('roles.show',$role->id)); ?>">Mostrar</a>
                                           <?php endif; // Entrust::can ?>

                                         <?php if (\Entrust::can('role-update')) : ?>
                                       <a class="btn btn-primary" href="<?php echo e(route('roles.edit',$role->id)); ?>">Editar</a>

                                           <?php endif; // Entrust::can ?>
                                    

                                        <?php if (\Entrust::can('role-delete')) : ?>
                                        <form action="<?php echo e(url('admin/roles/'.$role->id)); ?>" method="POST" style="display: inline-block">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>


                                            <button type="submit" id="delete-task-<?php echo e($role->id); ?>" class="btn btn-danger">
                                                <i class="fa fa-btn fa-trash"></i>Eliminar
                                            </button>
                                        </form>

                                             <?php endif; // Entrust::can ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                      

       <?php if (\Entrust::can('role-create')) : ?>
 <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-success">Nuevo Rol</a>
<?php endif; // Entrust::can ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>