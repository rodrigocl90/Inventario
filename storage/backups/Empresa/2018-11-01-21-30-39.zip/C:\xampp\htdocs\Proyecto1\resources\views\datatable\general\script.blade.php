


  <script type="text/javascript" src="{{asset('datatable/js/jquery.js')}}"></script>
  <script type="text/javascript" src="{{asset('datatable/js/jquery-1.11.3.min.js')}}"></script>
  <script type="text/javascript" src="{{asset('datatable/js/jquery.dataTables.min.js')}}"></script>
  <script type="text/javascript" src="{{asset('datatable/js/dataTables.buttons.min.js')}}"></script>
  

  <script src="/vendor/datatables/buttons.server-side.js"></script>
 <link rel="stylesheet" href="{{asset('datatable/css/jquery.dataTables.min.css')}}">
 <link rel="stylesheet" href="{{asset('datatable/css/dataTables.bootstrap.min.css')}}">
 <link rel="stylesheet" href="{{asset('datatable/css/buttons.dataTables.min.css')}}">
 <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">

