<!doctype html>
<html>
<head>
<meta charset="utf-8">
<!-- TemplateBeginEditable name="doctitle" -->
<title>Documento sin título</title>
<!-- TemplateEndEditable -->
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
</head>

<body>
<table width="481" height="157" border="1">
  <caption>
    xzxxx
  </caption>
  <tbody>
    <tr>
      <th width="219" scope="col"><label for="email">Email:</label>
      <input type="email" name="email" id="email"></th>
      <th width="246" scope="col"><label for="tel">Tel:</label>
      <input name="tel" type="tel" autofocus="autofocus" id="tel" value="fgfhgfgh" size="10" maxlength="10" readonly="readonly"></th>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </tbody>
</table>
</body>
</html>
