<?php $__env->startSection('title', 'Pagina No encontrada'); ?>

<?php $__env->startSection('message', 'Lo siento, la página que buscas no existe.'); ?>

<?php echo $__env->make('errors::layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>