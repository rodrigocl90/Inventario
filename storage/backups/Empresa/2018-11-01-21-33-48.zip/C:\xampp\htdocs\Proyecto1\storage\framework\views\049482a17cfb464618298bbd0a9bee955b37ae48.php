<?php ?>





<?php $__env->startSection('headder'); ?>



<ol class="breadcrumb">
      <li><a><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-user"></i> Usuarios</a></li>
  <li class="active"><i class="fa fa-th"></i>Crear Usuario</li>
</ol>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>



    <div class="container">
        <div class="row">
          <div class="col-md-1">
            <img src="<?php echo e(asset('img/usuarios.png')); ?>" width="200px" class="user-image" alt="User Image">
          </div>

  <div class="col-md-7  col-md-offset-2">

                <div class="panel panel-primary ">
                    <div class="panel-heading">
                     <h4 align="center">Crear Usuario</h4></div>

                    <div class="panel-body">
                        <!-- Display Validation Errors -->
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> Problemas al ingresar datos.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


     <?php echo e(Form::open(['route'=>'users.store','method'=>'POST'])); ?>


  <?php echo e(csrf_field()); ?>



  <div class="form-group">
     <div class="form-group <?php echo e($errors->has('name') ? 'has-error' :''); ?>">
             <?php echo e(Form::label('lname', 'Nombre de Identificación Usuario', ['class' => 'control-label'])); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                 <?php echo e(Form::text('name', null, ['class' => 'form-control awesome','maxlength' => 30,'placeholder'=>'ingrese nombre usuario','required' => 'required'])); ?>

                </div>
              </div>
            </div>
</div>

 <div class="form-group">
     <div class="form-group <?php echo e($errors->has('first_name') ? 'has-error' :''); ?>">
             <?php echo e(Form::label('lfirst_name', 'Nombres', ['class' => 'control-label'])); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                 <?php echo e(Form::text('first_name', null, ['class' => 'form-control awesome','maxlength' => 120,'placeholder'=>'ingrese nombres del usuario','required' => 'required'])); ?>

                </div>
              </div>
            </div>
</div>

 <div class="form-group">
     <div class="form-group <?php echo e($errors->has('last_name') ? 'has-error' :''); ?>">
             <?php echo e(Form::label('llast_name', 'Apellidos', ['class' => 'control-label'])); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                 <?php echo e(Form::text('last_name', null, ['class' => 'form-control awesome','maxlength' => 120,'placeholder'=>'ingrese Apellidos del usuario','required' => 'required'])); ?>

                </div>
              </div>
            </div>
</div>



    <div class="form-group">
      <div class="form-group <?php echo e($errors->has('email') ? 'has-error' :''); ?>">
              <?php echo e(Form::label('lemail', 'Dirección Email')); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
                 <?php echo e(Form::text('email', null, ['class' => 'form-control awesome','maxlength' => 191, 'placeholder'=>'ingrese correo','required' => 'required'])); ?>

                </div>
              </div>
            </div>
</div>

  <div class="form-group">
      <div class="form-group <?php echo e($errors->has('password') ? 'has-error' :''); ?>">
              <?php echo e(Form::label('lcontraseña', 'contraseña')); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                    <?php echo e(Form::password('password', ['class' => 'form-control awesome','maxlength' => 128,'placeholder'=>'ingrese contraseña','required' => 'required'])); ?>

                </div>
              
              </div>
            </div>
          </div>


  <div class="form-group">
      <div class="form-group <?php echo e($errors->has('password_confirmation') ? 'has-error' :''); ?>">
                <?php echo e(Form::label('lPasswordmm', 'confirmar contraseña')); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                  <?php echo e(Form::password('password_confirmation', ['class' => 'form-control awesome','maxlength' => 128,'placeholder'=>'confirme contraseña'])); ?>

                </div>
              
              </div>
            </div>
          </div>



  <div class="form-group">
      <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' :''); ?>">
                   <?php echo e(Form::label('lphone', 'Nº móvil', ['class' => 'control-label'])); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-phone fa-lg" aria-hidden="true"></i></span>
                  <?php echo e(Form::text('phone', null, array('placeholder' => '','maxlength' => 9,'class' => 'form-control awesome','placeholder'=>'ingrese teléfono','required' => 'required'))); ?>

                </div>
              
              </div>
            </div>
          </div>


  <div class="form-group">
          <div class="form-group <?php echo e($errors->has('roles') ? 'has-error' :''); ?>">
                          <?php echo e(Form::label('lroles', 'Roles', ['class' => 'control-label'])); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-unlock
 fa-lg" aria-hidden="true" title="Mantenga la tecla CTRL para marcar más de una opción"></i></span>
             
    
      <?php echo e(Form::select('roles[]',$roles,null,array('class'=>'form-control', 'multiple'=>'multiple','required'))); ?>

                </div>
              
              </div>
            </div>
          </div>

   
     <div class="form-group">
    <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' :''); ?>">
       <?php echo e(Form::label('lsexo', 'Sexo')); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-genderless
 fa-lg" aria-hidden="true"></i></span>
                
     <?php echo e(Form::select('gender', ['0'=>'elige un sexo','m' => 'mujer', 'h' => 'hombre'], null, ['class' => 'form-control awesome','required'])); ?>

                </div>
              
              </div>
            </div>
          </div>



    <div class="form-group">
   
    <div class="form-group <?php echo e($errors->has('status') ? 'has-error' :''); ?>">
      <?php echo e(Form::label('lEstado', 'Estado cuenta ususaria')); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-check
 fa-lg" aria-hidden="true"></i></span>
                
     <?php echo e(Form::select('status', ['9' => 'selecciona un estado de cuenta','0' => 'Inactiva','1' => 'Activo'], null, ['class' => 'form-control awesome'])); ?>

                </div>
              
              </div>
            </div>
          </div>


<div class="form-group">

<?php echo e(Form::submit('Guardar', ['class' => 'btn btn-info'])); ?>



                                    <a class="btn btn-warning" href="<?php echo e(url('admin/users')); ?>">
                                        Cancelar
                                    </a>
<?php echo e(Form::close()); ?>

</div>

                    </div>
                </div>
           
        </div>
          
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>