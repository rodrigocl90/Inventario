<?php ?>





<?php $__env->startSection('headder'); ?>


    <ol class="breadcrumb">
  <li><a><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li class="active"><i class="fa fa-th"></i>Usuarios</li>
  
</ol>
   

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>



<?php if (\Entrust::can('user-create')) : ?>

    <button  class="btn btn-danger glyphicon glyphicon-trash linea" data-toggle="modal" data-target="#myModal" title="eliminar">Eliminar Registros</button>
<br/>
<br/>
    <?php endif; // Entrust::can ?>
<?php echo $__env->make('datatable.general.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div style="overflow-x:auto;"  align="center" margin="0 auto" >

<?php echo e($dataTable->table(['class' => 'table-responsive warning grocery-crud-table cell-border table-hover compact dataTable_width_auto table-striped', 'id' => 'table'])); ?>

</div>

<?php echo $dataTable->scripts(); ?>


<?php echo $__env->make('flashy::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>







<div class="modal modal-danger fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title text-center" id="myModalLabel">Confirmar Eliminación Logs</h4>
      </div>
     <form class="w3-container" action="<?php echo e(route('logs.delete')); ?>">
          <?php echo e(csrf_field()); ?>

        <div class="modal-body">
        <p class="text-center">
        Estás seguro de eliminar Los registros 
        </p>
          

        </div>
        <div class="modal-footer">
     
          <button type="submit" class="btn btn-warning">Sí</button>
         <button type="button" class="btn btn-info" data-dismiss="modal">No</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>