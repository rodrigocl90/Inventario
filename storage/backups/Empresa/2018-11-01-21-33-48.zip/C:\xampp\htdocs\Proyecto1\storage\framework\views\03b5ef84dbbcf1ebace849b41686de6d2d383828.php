<?php ?>





<?php $__env->startSection('headder'); ?>

    <ol class="breadcrumb">
  <li><a><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-user"></i> Usuarios</a></li>
  <li class="active"><i class="fa fa-th"></i>Información Usuario</li>
</ol>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

<style type="text/css">
    read-only {
  color: red !important;
}
    .read{ background: white !important;
     }


.blue{
    color:brown;
}
.red{
color: red;

}
.bn{

    margin: 15px;
    background-color: #EFEDF1;
    border: 1px solid #E2E3E8;
    padding: 10px;  
    word-break: break-all; 

}
.btn{
white-space: normal;

}
</style>



    <div class="row ">
        <div class="panel panel-primary bn">
                    <div class="panel-heading" >
                     <h4 align="center" style=" font-style: italic;">Información de Usuario</h4></div>

                  </div>
        <div class="col-md-3">

 <div class="text-center">
       <br>
             <img src="<?php echo e(asset('img/jho.png')); ?>" class="avatar img-circle img-thumbnail" alt="User Image">


   <div class="panel panel-primary ">
                    <div class="panel-heading" >
              <h4 class="aju"><?php echo e($user->name); ?></h4>
                     <h5 align="center" style=" font-style: italic;"><?php echo e($user->email); ?></h5>

             
                     <a class="btn btn-warning" href="<?php echo e(url('admin/users')); ?>">
                                        Regresar
                                    </a>


                 </div>

                  </div>

      </div>



        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-body" >
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                           <div class="alert alert-info">
Información Perfil Usuario
</div>

                                    
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">            
        


            <div class="form-group row">
         <label class="col-md-4" for="Date Of Birth">Nombre Usuario</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class=" fa fa-user blue"></i>
        
       </div>
        <?php echo e(Form::text('tname',$user->name, ['class' => 'red read col-md-4 form-control input-md','readonly'])); ?>

 
    </div>    
  </div>
</div>


            <div class="form-group row">
         <label class="col-md-4" for="Date Of Birth">Nombres del Usuario</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class=" fa fa-user blue"></i>
        
       </div>
        <?php echo e(Form::text('tfirst_name',$user->first_name, ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

 
    </div>    
  </div>
</div>

       <div class="form-group row">
         <label class="col-md-4" for="Date Of Birth">Apellidos del Usuario</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class=" fa fa-user blue"></i>
        
       </div>
        <?php echo e(Form::text('tlast_name',$user->last_name, ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

 
    </div>    
  </div>
</div>


       

      <div class="form-group row">
         <label class="col-md-4" for="Date Of Birth">Email</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-envelope fa blue"></i>
        
       </div>
             <?php echo e(Form::text('tmail',$user->email, ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

      </div>    
  </div>
</div>
      



        <div class="form-group row">
         <label class="col-md-4" for="Date Of Birth">Roles del Usuario</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-group blue"></i>
        
       </div>                         <?php if(!empty($user->roles)): ?>
                                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
                                 <?php echo e(Form::text('tmailz',$role->display_name , ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
      </div>    
  </div>
</div>



        <div class="form-group row">
         <label class="col-md-4" for="Date Of Birth">Estado de Cuenta</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-power-off blue"></i>
        
       </div>                    
            <?php if($user->status===0): ?>
                               
                 <?php echo e(Form::text('tstatus','Inactica', ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

                               
                            <?php endif; ?>

                             <?php if($user->status===1 ): ?>
                               
             <?php echo e(Form::text('tstatus','Activa', ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

                               
                            <?php endif; ?>
                            
                            
      </div>    
  </div>
</div>


      <div class="form-group row">
         <label class="col-md-4" for="Date Of Birth">Sexo</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-asterisk blue"></i>
        
       </div>                         <?php if($user->gender==="m" ): ?>
                               
             <?php echo e(Form::text('Tsexo','Mujer', ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

                               
                            <?php endif; ?>

                             <?php if($user->gender==="h" ): ?>
                               
                    <?php echo e(Form::text('Tsexo','Hombre', ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

                               
                            <?php endif; ?>
                            
                            
      </div>    
  </div>
</div>


  <div class="form-group row">
         <label class="col-md-4" for="Date Of Birth">Nº móvil</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-phone fa blue"></i>
        
       </div>
             <?php echo e(Form::text('tphone',$user->phone, ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

      </div>    
  </div>
</div>
      


  <div class="form-group row">
         <label class="col-md-4" for="Date Of Birth">Fecha Creación Usuario</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-calendar blue"></i>
        
       </div>
             <?php echo e(Form::text('tcreacion',date_format($user->created_at, 'd/m/Y H:i:s'), ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

      </div>    
  </div>
</div>


  <div class="form-group row">
         <label class="col-md-4" for="Date Of Birth">Fecha última Actualización de datos</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-calendar blue"></i>
        
       </div>
             <?php echo e(Form::text('tcreacion',date_format($user->updated_at, 'd/m/Y H:i:s'), ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

      </div>    
  </div>
</div>





                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>                                          

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>