<?php ?>





<?php $__env->startSection('headder'); ?>

     <ol class="breadcrumb">
  <li><a><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li><a href="<?php echo e(route('roles.index')); ?>"><i class="fa fa-user"></i>Roles</a></li>
  <li class="active"><i class="fa fa-th"></i>Creación</li>
</ol>
   

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading"><h4 align="center">Editar Roles</h4></div>

                    <div class="panel-body">
                        <!-- Display Validation Errors -->
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> Problemas en el ingreso de datos<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


                        <form class="form-horizontal" role="form" method="POST"
                              action="<?php echo e(url('admin/roles/'.$role->id)); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>


                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-md-4 control-label">Nombre </label>

                                <div class="col-md-6">
                                    <?php echo e(Form::text('name', $role->name, ['class' => 'form-control awesome','placeholder'=>'ingrese nombre','required' => 'required'])); ?>


                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                              <div class="form-group<?php echo e($errors->has('display_name') ? ' has-error' : ''); ?>">
                                <label for="description" class="col-md-4 control-label">Nombre para mostrar</label>

                                <div class="col-md-6">
                                     <?php echo e(Form::text('display_name', $role->display_name, ['class' => 'form-control awesome','placeholder'=>'ingrese nombre a desplegar','required' => 'required'])); ?>


                                    <?php if($errors->has('display_name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('display_name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                                <label for="description" class="col-md-4 control-label">Descripcion</label>

                                <div class="col-md-6">
                                     <?php echo e(Form::text('description', $role->description, ['class' => 'form-control awesome','placeholder'=>'ingrese descripcion','required' => 'required'])); ?>


                                    <?php if($errors->has('description')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('permissions') ? ' has-error' : ''); ?>">
                                <label for="permission" class="col-md-4 control-label">Permisos</label>

                                <div class="col-md-6">
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="checkbox" value="<?php echo e($permission->id); ?>"
                                               <?php echo e(in_array($permission->id, $rolePermissions) ? "checked" : null); ?> name="permissions[]">
                                        <?php echo e($permission->display_name); ?><b>(<?php echo e(($permission->description)); ?>)</b><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($errors->has('permissions')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('permissions')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>









<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div class="modal-dialog modal-notify modal-warning" role="document">
    <div class="modal-content">
      <div class="modal-header">
           <h3 class="modal-title">Estas seguro de Guardar los cambios</h3>
         <form class="w3-container"  onKeypress="if(event.keyCode == 13) event.returnValue = false;">
            
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="glyphicon glyphicon-erase"></i>

          <span id="nombre" style="font-family: sans-serif; color:black"></span>
             (se guardaran los cambios de la cuenta del rol)

          

    
      <div class="modal-footer">
         <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-info'])); ?>

        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      
    </div>
        </form>
         </div>
      </div>

    </div>
  </div>










                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                    
<button class="btn btn-success glyphicon" data-toggle="modal" data-target="#myModal" title="guardar">Guardar  Cambios</button>

                                    <a class="btn btn-warning" href="<?php echo e(url('admin/roles')); ?>">
                                        Cancelar
                                    </a>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>